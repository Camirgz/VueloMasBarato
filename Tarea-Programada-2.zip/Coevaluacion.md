# Coevaluación

### Yos

---

**Cami**: 10/10
Muy leal y trabajadora.

**Jime**: 10/10
Innovadora al buscar soluciones.

### Jime

---

**Cami**: 10/10
Buen apoyo en el trabajo, responsable, trabajadora, buen ambiente de trabajo, búsqueda de soluciones con buena actitud

**Yos**: 10/10
Muy cooperativa, dispuesta a explicar procedimientos, buen apoyo, muy ingeniosa

### Cami

---

**Yos**: 10/10

Muy trabajadora, siempre atenta y puntual a las reuniones, además de una gran actitud al momento de trabajar en la tarea sin importar las circunstancias.

**Jime**: 10/10

Ingeniosa al momento de encontrar diferentes formas de llegar a una solución.